document.addEventListener('DOMContentLoaded', () => {
    const startButton = document.getElementById('start-note-detection');
    const statusMessage = document.getElementById('status-message');

    let audioContext;
    let analyser;
    let microphone;

    const initializeAudio = async () => {
        try {
            audioContext = new (window.AudioContext || window.webkitAudioContext)();
            analyser = audioContext.createAnalyser();
            analyser.fftSize = 2048;

            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            microphone = audioContext.createMediaStreamSource(stream);
            microphone.connect(analyser);

            if (statusMessage) {
                statusMessage.textContent = 'Audio initialized successfully.';
            }
            console.log('AUDIATION STATION: Audio initialized.');
            return true;
        } catch (error) {
            if (statusMessage) {
                statusMessage.textContent = 'Error initializing audio: ' + error.message;
            }
            console.error('AUDIATION STATION: Error initializing audio:', error);
            return false;
        }
    };

    if (startButton) {
        startButton.addEventListener('click', async () => {
            if (!audioContext) {
                const success = await initializeAudio();
                if (success) {
                    // Start note detection logic here
                }
            } else {
                // Note detection is already running or paused
            }
        });
    }
});


