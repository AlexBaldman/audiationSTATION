document.addEventListener("DOMContentLoaded", function() {
    const kickPad = document.getElementById("kick-pad");
    const snarePad = document.getElementById("snare-pad");
    const hihatPad = document.getElementById("hihat-pad");
    const cymbalPad = document.getElementById("cymbal-pad");

    let audioContext;

    // Function to create a simple oscillator sound
    function playSound(frequency, type, duration) {
        if (!audioContext) {
            audioContext = new (window.AudioContext || window.webkitAudioContext)();
        }

        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();

        oscillator.type = type; // 'sine', 'square', 'sawtooth', 'triangle'
        oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime);

        gainNode.gain.setValueAtTime(1, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + duration);

        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);

        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + duration);
    }

    // Function to create a more realistic drum sound (using Web Audio API for synthesis)
    function playDrumSound(type) {
        if (!audioContext) {
            audioContext = new (window.AudioContext || window.webkitAudioContext)();
        }

        const bufferSize = audioContext.sampleRate * 0.5; // 0.5 seconds of sound
        const buffer = audioContext.createBuffer(1, bufferSize, audioContext.sampleRate);
        const data = buffer.getChannelData(0);

        for (let i = 0; i < bufferSize; i++) {
            switch (type) {
                case "kick":
                    // Simple kick drum sound (decaying sine wave)
                    data[i] = Math.sin(i / (audioContext.sampleRate / 100) * Math.PI) * Math.exp(-i / (audioContext.sampleRate * 0.05));
                    break;
                case "snare":
                    // Simple snare drum sound (white noise + sine wave)
                    data[i] = (Math.random() * 2 - 1) * 0.6 + Math.sin(i / (audioContext.sampleRate / 200) * Math.PI) * 0.4;
                    data[i] *= Math.exp(-i / (audioContext.sampleRate * 0.1));
                    break;
                case "hihat":
                    // Simple hi-hat sound (white noise with quick decay)
                    data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (audioContext.sampleRate * 0.03));
                    break;
                case "cymbal":
                    // Simple cymbal sound (more complex noise with longer decay)
                    data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (audioContext.sampleRate * 0.5)) * 0.8 + (Math.random() * 2 - 1) * Math.exp(-i / (audioContext.sampleRate * 0.1)) * 0.2;
                    break;
                default:
                    data[i] = 0;
            }
        }

        const source = audioContext.createBufferSource();
        source.buffer = buffer;

        const gainNode = audioContext.createGain();
        gainNode.gain.setValueAtTime(1, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.5);

        source.connect(gainNode);
        gainNode.connect(audioContext.destination);

        source.start(0);
    }

    if (kickPad) {
        kickPad.addEventListener("click", () => playDrumSound("kick"));
    }
    if (snarePad) {
        snarePad.addEventListener("click", () => playDrumSound("snare"));
    }
    if (hihatPad) {
        hihatPad.addEventListener("click", () => playDrumSound("hihat"));
    }
    if (cymbalPad) {
        cymbalPad.addEventListener("click", () => playDrumSound("cymbal"));
    }
});


