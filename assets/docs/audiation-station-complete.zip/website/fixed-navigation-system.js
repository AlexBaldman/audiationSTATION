document.addEventListener("DOMContentLoaded", function() {
    // This script is primarily for ensuring smooth navigation and active link highlighting.
    // It works in conjunction with app-initializer.js for scroll-based highlighting.

    const navLinks = document.querySelectorAll(".nav-links a");

    navLinks.forEach(link => {
        link.addEventListener("click", function(event) {
            // Remove active class from all links
            navLinks.forEach(l => l.classList.remove("active"));

            // Add active class to the clicked link
            this.classList.add("active");

            // If it's an internal link to a section on the same page (index.html#section)
            if (this.getAttribute("href").startsWith("index.html#")) {
                event.preventDefault(); // Prevent default anchor jump
                const targetId = this.getAttribute("href").split("#")[1];
                const targetSection = document.getElementById(targetId);
                if (targetSection) {
                    targetSection.scrollIntoView({
                        behavior: "smooth"
                    });
                }
            }
            // For external HTML pages, the browser will handle navigation
        });
    });

    // Handle initial active state based on current page or hash
    const currentPath = window.location.pathname.split("/").pop();
    const currentHash = window.location.hash;

    navLinks.forEach(link => {
        const linkHref = link.getAttribute("href");
        if (linkHref === currentPath || (currentPath === "index.html" && linkHref.includes(currentHash))) {
            link.classList.add("active");
        }
    });
});


