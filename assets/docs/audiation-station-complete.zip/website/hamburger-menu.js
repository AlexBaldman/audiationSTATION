document.addEventListener("DOMContentLoaded", function() {
    const hamburger = document.querySelector(".hamburger-menu");
    const navLinks = document.querySelector(".nav-links");
    
    // Create overlay element
    const overlay = document.createElement('div');
    overlay.className = 'nav-overlay';
    document.body.appendChild(overlay);

    if (hamburger && navLinks) {
        hamburger.addEventListener("click", function() {
            hamburger.classList.toggle("active");
            navLinks.classList.toggle("active");
            overlay.classList.toggle("active");
        });

        // Close menu when overlay is clicked
        overlay.addEventListener("click", function() {
            hamburger.classList.remove("active");
            navLinks.classList.remove("active");
            overlay.classList.remove("active");
        });

        // Close menu when a link is clicked
        navLinks.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                hamburger.classList.remove("active");
                navLinks.classList.remove("active");
                overlay.classList.remove("active");
            });
        });

        // Close menu with Escape key
        document.addEventListener("keydown", function(e) {
            if (e.key === "Escape" && navLinks.classList.contains("active")) {
                hamburger.classList.remove("active");
                navLinks.classList.remove("active");
                overlay.classList.remove("active");
            }
        });
    }
});


