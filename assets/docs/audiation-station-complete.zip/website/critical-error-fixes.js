document.addEventListener("DOMContentLoaded", function() {
    // Global error handling to catch uncaught exceptions
    window.onerror = function(message, source, lineno, colno, error) {
        console.error("Global Error Caught:", {
            message: message,
            source: source,
            lineno: lineno,
            colno: colno,
            error: error
        });
        // Optionally display a user-friendly message
        // alert("An unexpected error occurred. Please try again.");
        return true; // Prevent default error handling
    };

    // Handle unhandled promise rejections
    window.addEventListener("unhandledrejection", function(event) {
        console.error("Unhandled Promise Rejection:", event.reason);
        // Optionally display a user-friendly message
        // alert("A promise error occurred. Please try again.");
    });

    // Ensure audio context resumes on user interaction for iOS/Safari
    // This is often handled in audio-init-handler.js, but a fallback here is good.
    document.body.addEventListener("touchstart", resumeAudioContext, { once: true });
    document.body.addEventListener("mousedown", resumeAudioContext, { once: true });

    function resumeAudioContext() {
        if (window.audioContext && window.audioContext.state === "suspended") {
            window.audioContext.resume().then(() => {
                console.log("AudioContext resumed successfully.");
            }).catch(e => {
                console.error("Error resuming AudioContext:", e);
            });
        }
    }

    // Add any other critical fixes here, e.g., for specific browser quirks
    // Example: Prevent default touch behavior for elements that should be clickable
    document.querySelectorAll("button, a").forEach(el => {
        el.addEventListener("touchstart", function(e) {
            // e.preventDefault(); // Use with caution, can break scrolling
        }, { passive: false });
    });

    console.log("Critical error fixes loaded.");
});


