document.addEventListener('DOMContentLoaded', () => {
    const debugButton = document.getElementById('debug-audio');

    if (debugButton) {
        debugButton.addEventListener('click', async () => {
            console.log('AUDIATION STATION: Starting audio debug...');
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                console.log('AUDIATION STATION: Microphone access granted.');
                const audioContext = new (window.AudioContext || window.webkitAudioContext)();
                console.log('AUDIATION STATION: AudioContext created.', audioContext);
                const source = audioContext.createMediaStreamSource(stream);
                console.log('AUDIATION STATION: MediaStreamSource created.', source);
                const analyser = audioContext.createAnalyser();
                console.log('AUDIATION STATION: AnalyserNode created.', analyser);
                source.connect(analyser);
                console.log('AUDIATION STATION: Source connected to analyser.');
                alert('Audio debug successful! Check the console for details.');
            } catch (error) {
                console.error('AUDIATION STATION: Audio debug failed:', error);
                alert('Audio debug failed: ' + error.message);
            }
        });
    }
});


