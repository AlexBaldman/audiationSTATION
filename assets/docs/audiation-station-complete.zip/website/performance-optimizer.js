document.addEventListener("DOMContentLoaded", function() {
    // Optimize animations for lower-end devices
    const reduceMotionQuery = window.matchMedia("(prefers-reduced-motion: reduce)");

    function handleReduceMotionChange() {
        if (reduceMotionQuery.matches) {
            document.body.classList.add("reduce-motion");
        } else {
            document.body.classList.remove("reduce-motion");
        }
    }

    reduceMotionQuery.addEventListener("change", handleReduceMotionChange);
    handleReduceMotionChange(); // Initial check

    // Lazy load non-critical images (if any)
    const lazyImages = document.querySelectorAll("img.lazyload");
    if ("IntersectionObserver" in window) {
        let lazyImageObserver = new IntersectionObserver(function(entries, observer) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    let lazyImage = entry.target;
                    lazyImage.src = lazyImage.dataset.src;
                    lazyImage.classList.remove("lazyload");
                    lazyImageObserver.unobserve(lazyImage);
                }
            });
        });

        lazyImages.forEach(function(lazyImage) {
            lazyImageObserver.observe(lazyImage);
        });
    } else {
        // Fallback for browsers that don't support IntersectionObserver
        lazyImages.forEach(function(lazyImage) {
            lazyImage.src = lazyImage.dataset.src;
            lazyImage.classList.remove("lazyload");
        });
    }

    // Debounce scroll and resize events for performance
    let throttleTimer;
    const throttle = (callback, time) => {
        if (throttleTimer) return;
        throttleTimer = setTimeout(() => {
            callback();
            throttleTimer = null;
        }, time);
    };

    window.addEventListener("scroll", () => {
        throttle(() => {
            // console.log("Scroll event throttled");
            // Add any scroll-dependent logic here
        }, 100);
    });

    window.addEventListener("resize", () => {
        throttle(() => {
            // console.log("Resize event throttled");
            // Add any resize-dependent logic here
        }, 200);
    });

    // Basic memory management (example: clear large arrays/objects when not needed)
    // This is highly application-specific. For example:
    // let largeDataArray = [];
    // function clearLargeData() {
    //     largeDataArray = null; // Allow garbage collection
    // }
    // window.addEventListener("beforeunload", clearLargeData);
});


