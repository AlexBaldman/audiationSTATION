document.addEventListener("DOMContentLoaded", function() {
    const startButton = document.getElementById("start-note-detection");
    const stopButton = document.getElementById("stop-note-detection");
    const statusMessage = document.getElementById("status-message");
    const noteDisplay = document.getElementById("note-display");
    const frequencyDisplay = document.getElementById("frequency-display");
    const waveformCanvas = document.getElementById("waveform-canvas");
    const canvasCtx = waveformCanvas ? waveformCanvas.getContext("2d") : null;

    let audioContext;
    let analyser;
    let microphone;
    let isDetecting = false;
    let animationId;

    // Note frequencies (A4 = 440Hz as reference)
    const noteFrequencies = {
        "C": 261.63,
        "C#": 277.18,
        "D": 293.66,
        "D#": 311.13,
        "E": 329.63,
        "F": 349.23,
        "F#": 369.99,
        "G": 392.00,
        "G#": 415.30,
        "A": 440.00,
        "A#": 466.16,
        "B": 493.88
    };

    // Function to find the closest note
    function findClosestNote(frequency) {
        if (frequency < 80 || frequency > 2000) return null; // Filter out noise
        
        let closestNote = null;
        let minDifference = Infinity;

        for (const note in noteFrequencies) {
            // Check multiple octaves
            for (let octave = 1; octave <= 6; octave++) {
                const noteFreq = noteFrequencies[note] * Math.pow(2, octave - 4);
                const diff = Math.abs(noteFreq - frequency);
                if (diff < minDifference) {
                    minDifference = diff;
                    closestNote = note + octave;
                }
            }
        }
        
        // Only return note if it's close enough (within 50 cents)
        return minDifference < 30 ? closestNote : null;
    }

    // Function to draw waveform
    function drawWaveform() {
        if (!canvasCtx || !analyser || !isDetecting) return;

        animationId = requestAnimationFrame(drawWaveform);

        const bufferLength = analyser.fftSize;
        const dataArray = new Uint8Array(bufferLength);
        analyser.getByteTimeDomainData(dataArray);

        // Clear canvas
        canvasCtx.fillStyle = '#000';
        canvasCtx.fillRect(0, 0, waveformCanvas.width, waveformCanvas.height);

        // Draw waveform
        canvasCtx.lineWidth = 2;
        canvasCtx.strokeStyle = '#00ff00'; // Neon green waveform
        canvasCtx.beginPath();

        const sliceWidth = waveformCanvas.width * 1.0 / bufferLength;
        let x = 0;

        for (let i = 0; i < bufferLength; i++) {
            const v = dataArray[i] / 128.0;
            const y = v * waveformCanvas.height / 2;

            if (i === 0) {
                canvasCtx.moveTo(x, y);
            } else {
                canvasCtx.lineTo(x, y);
            }

            x += sliceWidth;
        }

        canvasCtx.lineTo(waveformCanvas.width, waveformCanvas.height / 2);
        canvasCtx.stroke();

        // Draw center line
        canvasCtx.strokeStyle = '#333';
        canvasCtx.lineWidth = 1;
        canvasCtx.beginPath();
        canvasCtx.moveTo(0, waveformCanvas.height / 2);
        canvasCtx.lineTo(waveformCanvas.width, waveformCanvas.height / 2);
        canvasCtx.stroke();
    }

    // Autocorrelation function for pitch detection
    function autoCorrelate(buffer, sampleRate) {
        const SIZE = buffer.length;
        const rms = Math.sqrt(buffer.reduce((sum, val) => sum + val * val, 0) / SIZE);
        
        if (rms < 0.01) return -1; // Not enough signal

        let r1 = 0, r2 = SIZE - 1;
        const thres = 0.2;
        
        // Find the beginning and end of the signal
        for (let i = 0; i < SIZE / 2; i++) {
            if (Math.abs(buffer[i]) < thres) { r1 = i; break; }
        }
        for (let i = 1; i < SIZE / 2; i++) {
            if (Math.abs(buffer[SIZE - i]) < thres) { r2 = SIZE - i; break; }
        }

        buffer = buffer.slice(r1, r2);
        const newSize = buffer.length;

        const c = new Array(newSize).fill(0);
        for (let i = 0; i < newSize; i++) {
            for (let j = 0; j < newSize - i; j++) {
                c[i] = c[i] + buffer[j] * buffer[j + i];
            }
        }

        let d = 0;
        while (c[d] > c[d + 1]) d++;
        
        let maxval = -1, maxpos = -1;
        for (let i = d; i < newSize; i++) {
            if (c[i] > maxval) {
                maxval = c[i];
                maxpos = i;
            }
        }

        let T0 = maxpos;
        
        // Parabolic interpolation
        if (maxpos > 0 && maxpos < newSize - 1) {
            const x1 = c[T0 - 1], x2 = c[T0], x3 = c[T0 + 1];
            const a = (x1 + x3 - 2 * x2) / 2;
            const b = (x3 - x1) / 2;
            if (a) T0 = T0 - b / (2 * a);
        }

        return sampleRate / T0;
    }

    // Function to get pitch
    function getPitch() {
        if (!analyser || !isDetecting) return;

        const bufferLength = analyser.fftSize;
        const buffer = new Float32Array(bufferLength);
        analyser.getFloatTimeDomainData(buffer);

        const pitch = autoCorrelate(buffer, audioContext.sampleRate);

        if (pitch > 0) {
            const note = findClosestNote(pitch);
            if (note) {
                noteDisplay.textContent = note;
                noteDisplay.style.color = '#00ff00';
                noteDisplay.style.transform = 'scale(1.1)';
            } else {
                noteDisplay.textContent = '~';
                noteDisplay.style.color = '#ffff00';
                noteDisplay.style.transform = 'scale(1)';
            }
            frequencyDisplay.textContent = pitch.toFixed(2) + " Hz";
        } else {
            noteDisplay.textContent = '--';
            noteDisplay.style.color = '#666';
            noteDisplay.style.transform = 'scale(1)';
            frequencyDisplay.textContent = "0 Hz";
        }

        // Continue pitch detection
        if (isDetecting) {
            setTimeout(getPitch, 50); // Update every 50ms
        }
    }

    // Start Note Detection
    if (startButton) {
        startButton.addEventListener("click", async () => {
            if (isDetecting) return;

            try {
                statusMessage.textContent = "Requesting microphone access...";
                
                audioContext = new (window.AudioContext || window.webkitAudioContext)();
                
                // Resume audio context if suspended (required for some browsers)
                if (audioContext.state === 'suspended') {
                    await audioContext.resume();
                }

                const stream = await navigator.mediaDevices.getUserMedia({ 
                    audio: {
                        echoCancellation: false,
                        noiseSuppression: false,
                        autoGainControl: false
                    } 
                });
                
                microphone = audioContext.createMediaStreamSource(stream);
                analyser = audioContext.createAnalyser();
                analyser.fftSize = 4096;
                analyser.smoothingTimeConstant = 0.8;
                microphone.connect(analyser);

                isDetecting = true;
                startButton.disabled = true;
                stopButton.disabled = false;
                statusMessage.textContent = "🎵 Note detection active - play or sing a note!";
                noteDisplay.textContent = "Listening...";
                frequencyDisplay.textContent = "...";

                // Start drawing waveform and getting pitch
                drawWaveform();
                getPitch();

                console.log("AUDIATION STATION: Note detection started successfully.");
            } catch (error) {
                statusMessage.textContent = "❌ Error: " + error.message;
                console.error("AUDIATION STATION: Error starting note detection:", error);
                
                // Reset buttons on error
                startButton.disabled = false;
                stopButton.disabled = true;
            }
        });
    }

    // Stop Note Detection
    if (stopButton) {
        stopButton.addEventListener("click", () => {
            if (!isDetecting) return;

            isDetecting = false;
            startButton.disabled = false;
            stopButton.disabled = true;
            statusMessage.textContent = "Note detection stopped.";
            noteDisplay.textContent = "--";
            frequencyDisplay.textContent = "0 Hz";

            // Cancel animation frame
            if (animationId) {
                cancelAnimationFrame(animationId);
            }

            // Clean up audio resources
            if (microphone) {
                microphone.disconnect();
                if (microphone.mediaStream) {
                    microphone.mediaStream.getTracks().forEach(track => track.stop());
                }
            }
            if (analyser) {
                analyser.disconnect();
            }
            if (audioContext) {
                audioContext.close().then(() => {
                    console.log("AUDIATION STATION: AudioContext closed.");
                });
            }

            // Clear waveform canvas
            if (canvasCtx) {
                canvasCtx.fillStyle = '#000';
                canvasCtx.fillRect(0, 0, waveformCanvas.width, waveformCanvas.height);
            }

            console.log("AUDIATION STATION: Note detection stopped.");
        });
    }

    // Initialize canvas dimensions
    if (waveformCanvas) {
        const resizeCanvas = () => {
            const rect = waveformCanvas.getBoundingClientRect();
            waveformCanvas.width = rect.width;
            waveformCanvas.height = rect.height;
            
            // Set minimum dimensions
            if (waveformCanvas.width < 300) waveformCanvas.width = 300;
            if (waveformCanvas.height < 150) waveformCanvas.height = 150;
        };
        
        resizeCanvas();
        window.addEventListener('resize', resizeCanvas);
    }
});


