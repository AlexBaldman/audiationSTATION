document.addEventListener('DOMContentLoaded', () => {
    console.log('AUDIATION STATION: DOM fully loaded and parsed.');

    // Initial check for audio context and microphone access
    // This will be handled by audio-init-handler.js

    // Hide the loading screen if it's still visible
    const loadingScreen = document.getElementById('loading-screen');
    if (loadingScreen) {
        loadingScreen.style.display = 'none';
        console.log('AUDIATION STATION: Loading screen hidden.');
    }

    // Initialize other components as needed
    // For example, if you have a theme toggler:
    // const themeToggle = document.getElementById('theme-toggle');
    // if (themeToggle) {
    //     themeToggle.addEventListener('click', () => {
    //         document.body.classList.toggle('dark-mode');
    //         document.body.classList.toggle('light-mode');
    //     });
    // }

    // Initialize navigation highlighting
    const navLinks = document.querySelectorAll('.nav-links a');
    const sections = document.querySelectorAll('section');

    const highlightActiveLink = () => {
        let current = '';
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;
            if (pageYOffset >= sectionTop - sectionHeight / 3) {
                current = section.getAttribute('id');
            }
        });

        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href').includes(current)) {
                link.classList.add('active');
            }
        });
    };

    window.addEventListener('scroll', highlightActiveLink);
    highlightActiveLink(); // Call on load to set initial active link

    console.log('AUDIATION STATION: Application initialized.');
});


