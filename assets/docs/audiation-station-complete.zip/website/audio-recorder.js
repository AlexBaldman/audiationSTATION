document.addEventListener("DOMContentLoaded", function() {
    const startRecordingButton = document.getElementById("start-recording");
    const stopRecordingButton = document.getElementById("stop-recording");
    const playRecordingButton = document.getElementById("play-recording");
    const saveRecordingButton = document.getElementById("save-recording");
    const recorderStatus = document.getElementById("recorder-status");
    const recordingTimer = document.getElementById("recording-timer");

    let mediaRecorder;
    let audioChunks = [];
    let audioBlob;
    let timerInterval;
    let startTime;

    if (startRecordingButton) {
        startRecordingButton.addEventListener("click", async () => {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                mediaRecorder = new MediaRecorder(stream);
                audioChunks = [];

                mediaRecorder.ondataavailable = event => {
                    audioChunks.push(event.data);
                };

                mediaRecorder.onstop = () => {
                    audioBlob = new Blob(audioChunks, { type: "audio/wav" });
                    playRecordingButton.disabled = false;
                    saveRecordingButton.disabled = false;
                    recorderStatus.textContent = "Recording stopped.";
                };

                mediaRecorder.start();
                recorderStatus.textContent = "Recording...";
                startRecordingButton.disabled = true;
                stopRecordingButton.disabled = false;
                playRecordingButton.disabled = true;
                saveRecordingButton.disabled = true;

                startTime = Date.now();
                timerInterval = setInterval(() => {
                    const elapsedTime = Date.now() - startTime;
                    const minutes = Math.floor(elapsedTime / 60000);
                    const seconds = Math.floor((elapsedTime % 60000) / 1000);
                    const milliseconds = Math.floor((elapsedTime % 1000) / 10);
                    recordingTimer.textContent = 
                        `${minutes.toString().padStart(2, '0')}:` +
                        `${seconds.toString().padStart(2, '0')}.` +
                        `${milliseconds.toString().padStart(2, '0')}`;
                }, 10);

                console.log("AUDIATION STATION: Recording started.");
            } catch (error) {
                recorderStatus.textContent = "Error starting recording: " + error.message;
                console.error("AUDIATION STATION: Error starting recording:", error);
            }
        });
    }

    if (stopRecordingButton) {
        stopRecordingButton.addEventListener("click", () => {
            if (mediaRecorder && mediaRecorder.state === "recording") {
                mediaRecorder.stop();
                clearInterval(timerInterval);
                startRecordingButton.disabled = false;
                stopRecordingButton.disabled = true;
                console.log("AUDIATION STATION: Recording stopped.");
            }
        });
    }

    if (playRecordingButton) {
        playRecordingButton.addEventListener("click", () => {
            if (audioBlob) {
                const audioUrl = URL.createObjectURL(audioBlob);
                const audio = new Audio(audioUrl);
                audio.play();
                recorderStatus.textContent = "Playing recording...";
                audio.onended = () => {
                    recorderStatus.textContent = "Recording playback finished.";
                };
                console.log("AUDIATION STATION: Playing recording.");
            }
        });
    }

    if (saveRecordingButton) {
        saveRecordingButton.addEventListener("click", () => {
            if (audioBlob) {
                const a = document.createElement("a");
                document.body.appendChild(a);
                a.style = "display: none";
                const url = URL.createObjectURL(audioBlob);
                a.href = url;
                a.download = "audiation_station_recording.wav";
                a.click();
                window.URL.revokeObjectURL(url);
                recorderStatus.textContent = "Recording saved.";
                console.log("AUDIATION STATION: Recording saved.");
            }
        });
    }
});


