document.addEventListener("DOMContentLoaded", function() {
    const navLinks = document.querySelectorAll(".nav-links a");

    navLinks.forEach(link => {
        link.addEventListener("click", function(event) {
            // For internal links (e.g., index.html#home)
            if (this.getAttribute("href").startsWith("index.html#")) {
                event.preventDefault();
                const targetId = this.getAttribute("href").split("#")[1];
                const targetSection = document.getElementById(targetId);
                if (targetSection) {
                    targetSection.scrollIntoView({
                        behavior: "smooth"
                    });
                }
            }
            // For external HTML pages, the browser will handle navigation
        });
    });

    // Highlight active link based on current page
    const currentPath = window.location.pathname.split("/").pop();
    navLinks.forEach(link => {
        if (link.getAttribute("href") === currentPath) {
            link.classList.add("active");
        } else if (currentPath === "index.html" && link.getAttribute("href").startsWith("index.html#home")) {
            // Special case for home link on index.html
            link.classList.add("active");
        }
    });
});


